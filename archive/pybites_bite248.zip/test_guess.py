from unittest.mock import patch

import pytest

from guess import GuessGame, InvalidNumber


# write test code to reach 100% coverage and a 100% mutpy score