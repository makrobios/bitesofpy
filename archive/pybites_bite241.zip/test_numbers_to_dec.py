import pytest

from numbers_to_dec import list_to_decimal