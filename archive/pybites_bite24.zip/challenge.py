from abc import ABC, abstractmethod


class Challenge(ABC):
    pass


class BlogChallenge(Challenge):
    pass


class BiteChallenge(Challenge):
    pass