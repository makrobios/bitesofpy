import sys

INTERNAL_LINKS = ('pybit.es', 'codechalleng.es')


def make_html_links():
    pass


if __name__ == '__main__':
    make_html_links()