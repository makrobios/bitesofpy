def binary_search(sequence, target):
    pass