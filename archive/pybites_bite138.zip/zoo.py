class Animal:

    def __init__(self, name):
        pass

    def __str__(self):
        pass

    @classmethod
    def zoo(cls):
        pass