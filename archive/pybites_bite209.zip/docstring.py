def sum_numbers(numbers):
    """Write your docstring here ..."""
    pass