def romanize(decimal_number):
    """Takes a decimal number int and converts its Roman Numeral str"""
    pass