def generate_affiliation_link(url):
    pass