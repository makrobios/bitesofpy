from datetime import datetime

PYBITES_BORN = datetime(year=2016, month=12, day=19)
days = datetime.timedelta(days=100)

def gen_special_pybites_dates():
    