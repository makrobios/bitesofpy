from datetime import datetime

NOW = datetime.now()


class Promo:
    pass