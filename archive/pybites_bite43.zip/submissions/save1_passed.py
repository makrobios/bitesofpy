def get_profile(*,name='julian', profession='programmer'):
    return '{} is a {}'.format(name, profession)


get_profile()