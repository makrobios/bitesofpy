def fizzbuzz(num):
    pass