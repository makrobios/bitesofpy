def flatten(list_of_lists):
    pass