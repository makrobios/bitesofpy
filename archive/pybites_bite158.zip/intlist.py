class IntList(list):
    pass