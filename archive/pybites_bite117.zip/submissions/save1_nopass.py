from math import round_even as rnd_evn

def round_even(number):
    """Takes a number and returns it rounded even"""
    return rnd_evn(number)