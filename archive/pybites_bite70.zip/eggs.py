from random import choice

COLORS = 'red blue green yellow brown purple'.split()


class EggCreator:
    pass